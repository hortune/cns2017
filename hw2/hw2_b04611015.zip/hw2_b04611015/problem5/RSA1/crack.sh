./RsaCtfTool-master/RsaCtfTool.py --publickey ./public.pem --uncipher ./flag.enc
