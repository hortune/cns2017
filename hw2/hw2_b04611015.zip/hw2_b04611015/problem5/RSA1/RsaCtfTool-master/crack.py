from base64 import b64encode
from base64 import b64decode

module="MDcwDQYJKoZIhvcNAQEBBQADJgAwIwIcDSMsOKIq+37o3bbZJV5ZzrcX4s9Y1UNK"
expo="Q06HdwIDAQAB"

