openssl req -new -x509 -days 1826 -out ca.crt >/dev/null
python attack.py
