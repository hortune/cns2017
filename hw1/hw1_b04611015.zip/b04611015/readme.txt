All the code is writen in python2.7 syntax with pwntools 
# code4.py
first open ipython
Then type %load code4.py to load the script.

It would auto complete stage 1.
Then it would print all possible stage 2 solution.
Choose the one with complete english.

conn.sendline(the one)
conn.recvuntil("3")
conn = solve_p345(conn)
conn = solve_p6(conn)
then the last one is by base64
just solve it by ("string").decode("base64")

# code5.py
python code5.py

# code6.py
ipython
%load code6.py

then use gen()
to see the result

use modify*(row,column,target) to make the location to your hope value
target is a char

since it needs some english background knowledge, we need to do it artificially

# code7.py
python code7.py

# code8.py
python code8.py
it would run for a pretty long time.

# code9.py
python code9.py
This depends on the hlextend package, which is a extension attack open source package.
